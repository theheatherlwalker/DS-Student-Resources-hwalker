my_message = "Hello World"
print(my_message)

animal_type = "cat"
print(animal_type)

human_age = 34
print(human_age)

weather = "bright and sunny"
print(weather)




my_message = "Hello World"
print(my_message)

my_message = "Hello World, how are you?"
print(my_message)




my_message = "Hello World, how are you?"

this_message = my_message
print(this_message)





my_message = "\tI should be shifted to the right"
print(my_message)

my_message = "I am on one line\nbut I'm on the next line"
print(my_message)





my_text = "She said \"Hello!\""
print(my_text)

my_message = 'What\'s your name?'
print(my_message)





add_two_numbers = 2 + 2
print(add_two_numbers)

multiply_two_numbers = 33 * 54
print(multiply_two_numbers)

multiply_three_numbers = 33 * 54 * 89
print(multiply_three_numbers)




add_two_float_numbers = 0.1 + 0.4
print(add_two_float_numbers)

multiply_two_float_numbers = 3 * 0.1
print(multiply_two_float_numbers)




###########################################
# DS109-01-17 - Variables Practice Hands-On

# 1. Create 3 variables to answer these questions:
# What is your name?
# How old are you?
# How many months is that? 
questionName = "What is your name?"
questionAgeYears = "How old are you?"
questionAgeMonths = "How many months is that?"



# 2. Create 3 more variables with these answers:
# My name is "Billy".
# 30
# 360
billyName = 'My name is "Billy".'
billyAgeYears = 30
billyAgeMonths = 360



# 3. Use the print function to output.
print(questionName)
print(billyName)
print(questionAgeYears)
print(billyAgeYears)
print(questionAgeMonths)
print(billyAgeMonths)



# 4. Comment out variables to print the output as
# What is your name?
# My name is "Billy".
# How old are you?
# 30
print(questionName)
print(billyName)
print(questionAgeYears)
print(billyAgeYears)
# print(questionAgeMonths)
# print(billyAgeMonths)



# 5. Create 3 new variables and 
# print them on separate lines.
# my_string
# my_integer
# my_float
my_string = 'My name is "Heather".'
my_integer = 36
my_float = 36.75

print(my_string)
print(my_integer)
print(my_float)


